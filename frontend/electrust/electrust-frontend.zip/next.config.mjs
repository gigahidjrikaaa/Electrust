// import { webpack } from 'next/dist/compiled/webpack/webpack';

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // pageExtensions:
  // {
  //   webpack:true
  // }
};

export default nextConfig;
